--inserez 5 utilizatori
INSERT INTO "USER" (name, password, email, register_date, last_login)
VALUES ('John Doe', 'Passwrd', 'john.doe@example.com', SYSDATE, SYSDATE);

INSERT INTO "USER" (name, password, email, register_date, last_login)
VALUES ('Alice Smith', 'Klujr', 'alice.smith@example.com', TO_DATE('2022-11-20', 'YYYY-MM-DD'), TO_DATE('2022-12-10', 'YYYY-MM-DD'));

INSERT INTO "USER" (name, password, email, register_date, last_login)
VALUES ('Bob Johnson', 'Vasdtgad', 'bob.johnson@example.com', TO_DATE('2022-10-25', 'YYYY-MM-DD'), TO_DATE('2022-11-05', 'YYYY-MM-DD'));

INSERT INTO "USER" (name, password, email, register_date, last_login)
VALUES ('Eva Miller', 'Lasdhfg', 'eva.miller@example.com', TO_DATE('2022-09-15', 'YYYY-MM-DD'), TO_DATE('2022-09-30', 'YYYY-MM-DD'));

INSERT INTO "USER" (name, password, email, register_date, last_login)
VALUES ('Sam Brown', 'Llasldflas', 'sam.brown@example.com', TO_DATE('2022-08-05', 'YYYY-MM-DD'), TO_DATE('2022-08-20', 'YYYY-MM-DD'));

select * from "USER";

--inserez pt fiecare user profilul cu detalii
INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES ((SELECT id_user FROM "USER" WHERE name = 'John Doe'), '1234567890', 'Reading, Cooking', 'A software engineer who loves to cook.', 'https://www.facebook.com/johndoe', 'City A');

INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES ((SELECT id_user FROM "USER" WHERE name = 'Alice Smith'), '9876543210', 'Photography, Traveling', 'An adventurous photographer.', 'https://www.facebook.com/alicesmith', 'City B');

INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES ((SELECT id_user FROM "USER" WHERE name = 'Bob Johnson'), '5551234567', 'Gaming, Coding', 'A gamer and programmer.', 'https://www.facebook.com/bobjohnson', 'City C');

INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES ((SELECT id_user FROM "USER" WHERE name = 'Eva Miller'), '9998887777', 'Painting, Yoga', 'An artist who enjoys yoga.', 'https://www.facebook.com/evamiller', 'City D');

INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES ((SELECT id_user FROM "USER" WHERE name = 'Sam Brown'), '3332221111', 'Sports, Music', 'A sports enthusiast and music lover.', 'https://www.facebook.com/sambrown', 'City E');

select * from profile;

--inserez categorii pentru postari 
INSERT INTO category (name) VALUES ('Technology');
INSERT INTO category (name) VALUES ('Travel');
INSERT INTO category (name) VALUES ('Food');
INSERT INTO category (name) VALUES ('Fitness');
INSERT INTO category (name) VALUES ('Fashion');
INSERT INTO category (name) VALUES ('Movies');
INSERT INTO category (name) VALUES ('Books');

select * from category order by id_category;

--inserez in tags 
INSERT INTO tags (name) VALUES ('#Programming');
INSERT INTO tags (name) VALUES ('#Adventure');
INSERT INTO tags (name) VALUES ('#Cooking');
INSERT INTO tags (name) VALUES ('#Fitness');
INSERT INTO tags (name) VALUES ('#Fashion');
INSERT INTO tags (name) VALUES ('#Movies');

select * from tags order by id_tag;


--inserez in post, postari de la utilizatori diferiti
INSERT INTO post (title, content, post_date, id_user, id_category)
VALUES ('Introduction to Python', 'Learn the basics of Python programming.', TO_DATE('2022-12-15', 'YYYY-MM-DD'), (SELECT id_user FROM "USER" WHERE name = 'John Doe'), (SELECT id_category FROM category WHERE name = 'Technology'));

INSERT INTO post (title, content, post_date, id_user, id_category)
VALUES ('Exploring Southeast Asia', 'A journey through the beautiful landscapes of Southeast Asia.', TO_DATE('2022-11-01', 'YYYY-MM-DD'), (SELECT id_user FROM "USER" WHERE name = 'Alice Smith'), (SELECT id_category FROM category WHERE name = 'Travel'));

INSERT INTO post (title, content, post_date, id_user, id_category)
VALUES ('Delicious Italian Recipes', 'Discover mouth-watering Italian dishes to try at home.', TO_DATE('2022-10-10', 'YYYY-MM-DD'), (SELECT id_user FROM "USER" WHERE name = 'Bob Johnson'), (SELECT id_category FROM category WHERE name = 'Food'));

INSERT INTO post (title, content, post_date, id_user, id_category)
VALUES ('Effective Home Workouts', 'Stay fit with these simple and effective home workout routines.', TO_DATE('2022-09-20', 'YYYY-MM-DD'), (SELECT id_user FROM "USER" WHERE name = 'Eva Miller'), (SELECT id_category FROM category WHERE name = 'Fitness'));

INSERT INTO post (title, content, post_date, id_user, id_category)
VALUES ('Latest Fashion Trends', 'Explore the hottest fashion trends of the season.', TO_DATE('2022-08-10', 'YYYY-MM-DD'), (SELECT id_user FROM "USER" WHERE name = 'Sam Brown'), (SELECT id_category FROM category WHERE name = 'Fashion'));

select * from post;





--inserez feedback de la utilizatori la postari, mai multi utilizatori la o postare, etc.
INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Introduction to Python'), (SELECT id_user FROM "USER" WHERE name = 'John Doe'), 'positive', TO_DATE('2022-12-16', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Exploring Southeast Asia'), (SELECT id_user FROM "USER" WHERE name = 'Alice Smith'), 'positive', TO_DATE('2022-11-02', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Delicious Italian Recipes'), (SELECT id_user FROM "USER" WHERE name = 'Bob Johnson'), 'negative', TO_DATE('2022-10-11', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Effective Home Workouts'), (SELECT id_user FROM "USER" WHERE name = 'Eva Miller'), 'positive', TO_DATE('2022-09-21', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Latest Fashion Trends'), (SELECT id_user FROM "USER" WHERE name = 'Sam Brown'), 'negative', TO_DATE('2022-08-11', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Exploring Southeast Asia'), (SELECT id_user FROM "USER" WHERE name = 'John Doe'), 'negative', TO_DATE('2022-12-17', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Delicious Italian Recipes'), (SELECT id_user FROM "USER" WHERE name = 'Alice Smith'), 'positive', TO_DATE('2022-11-03', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Effective Home Workouts'), (SELECT id_user FROM "USER" WHERE name = 'Bob Johnson'), 'positive', TO_DATE('2022-10-12', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Latest Fashion Trends'), (SELECT id_user FROM "USER" WHERE name = 'Eva Miller'), 'negative', TO_DATE('2022-09-22', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Introduction to Python'), (SELECT id_user FROM "USER" WHERE name = 'Sam Brown'), 'positive', TO_DATE('2022-08-12', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Delicious Italian Recipes'), (SELECT id_user FROM "USER" WHERE name = 'John Doe'), 'negative', TO_DATE('2022-12-18', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Effective Home Workouts'), (SELECT id_user FROM "USER" WHERE name = 'Alice Smith'), 'positive', TO_DATE('2022-11-04', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Latest Fashion Trends'), (SELECT id_user FROM "USER" WHERE name = 'Bob Johnson'), 'positive', TO_DATE('2022-10-13', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Introduction to Python'), (SELECT id_user FROM "USER" WHERE name = 'Eva Miller'), 'negative', TO_DATE('2022-09-23', 'YYYY-MM-DD'));

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES ((SELECT id_post FROM post WHERE title = 'Exploring Southeast Asia'), (SELECT id_user FROM "USER" WHERE name = 'Sam Brown'), 'positive', TO_DATE('2022-08-13', 'YYYY-MM-DD'));


select * from feedback;

--inserez comentarii de la utilizatori la postari
INSERT INTO "COMMENT" (content, comment_date, id_post, id_user)
VALUES ('Great tutorial! Really helpful for beginners.', TO_DATE('2022-12-16', 'YYYY-MM-DD'), (SELECT id_post FROM post WHERE title = 'Introduction to Python'), (SELECT id_user FROM "USER" WHERE name = 'John Doe'));

INSERT INTO "COMMENT" (content, comment_date, id_post, id_user)
VALUES ('The pictures are amazing! I want to visit these places.', TO_DATE('2022-11-02', 'YYYY-MM-DD'), (SELECT id_post FROM post WHERE title = 'Exploring Southeast Asia'), (SELECT id_user FROM "USER" WHERE name = 'Alice Smith'));

INSERT INTO "COMMENT" (content, comment_date, id_post, id_user)
VALUES ('I tried making the pasta recipe, and it was delicious!', TO_DATE('2022-10-11', 'YYYY-MM-DD'), (SELECT id_post FROM post WHERE title = 'Delicious Italian Recipes'), (SELECT id_user FROM "USER" WHERE name = 'Bob Johnson'));

INSERT INTO "COMMENT" (content, comment_date, id_post, id_user)
VALUES ('These workouts are perfect for staying fit at home.', TO_DATE('2022-09-21', 'YYYY-MM-DD'), (SELECT id_post FROM post WHERE title = 'Effective Home Workouts'), (SELECT id_user FROM "USER" WHERE name = 'Eva Miller'));

INSERT INTO "COMMENT" (content, comment_date, id_post, id_user)
VALUES ('Not a fan of the latest trends, but interesting read.', TO_DATE('2022-08-11', 'YYYY-MM-DD'), (SELECT id_post FROM post WHERE title = 'Latest Fashion Trends'), (SELECT id_user FROM "USER" WHERE name = 'Sam Brown'));

INSERT INTO "COMMENT" (content, comment_date, id_post, id_user)
VALUES ('This tutorial made learning Python so much easier!', TO_DATE('2022-12-17', 'YYYY-MM-DD'), (SELECT id_post FROM post WHERE title = 'Introduction to Python'), (SELECT id_user FROM "USER" WHERE name = 'Alice Smith'));

INSERT INTO "COMMENT" (content, comment_date, id_post, id_user)
VALUES ('I appreciate the step-by-step explanation. Well done!', TO_DATE('2022-12-18', 'YYYY-MM-DD'), (SELECT id_post FROM post WHERE title = 'Introduction to Python'), (SELECT id_user FROM "USER" WHERE name = 'Bob Johnson'));


select * from "COMMENT";


--legaturi m:m intre postari si taguri
INSERT INTO post_tags (id_post, id_tag)
VALUES ((SELECT id_post FROM post WHERE title = 'Introduction to Python'), (SELECT id_tag FROM tags WHERE name = '#Programming'));

INSERT INTO post_tags (id_post, id_tag)
VALUES ((SELECT id_post FROM post WHERE title = 'Exploring Southeast Asia'), (SELECT id_tag FROM tags WHERE name = '#Adventure'));

INSERT INTO post_tags (id_post, id_tag)
VALUES ((SELECT id_post FROM post WHERE title = 'Delicious Italian Recipes'), (SELECT id_tag FROM tags WHERE name = '#Cooking'));

INSERT INTO post_tags (id_post, id_tag)
VALUES ((SELECT id_post FROM post WHERE title = 'Effective Home Workouts'), (SELECT id_tag FROM tags WHERE name = '#Fitness'));

INSERT INTO post_tags (id_post, id_tag)
VALUES ((SELECT id_post FROM post WHERE title = 'Latest Fashion Trends'), (SELECT id_tag FROM tags WHERE name = '#Fashion'));

INSERT INTO post_tags (id_post, id_tag)
VALUES ((SELECT id_post FROM post WHERE title = 'Latest Fashion Trends'), (SELECT id_tag FROM tags WHERE name = '#Adventure'));

select * from post_tags;
select * from tags;
