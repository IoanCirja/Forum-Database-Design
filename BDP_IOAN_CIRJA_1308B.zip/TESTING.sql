--Selectarea postărilor și a categoriilor corespunzătoare si a autorilor
SELECT
    p.id_post,
    p.title AS post_title,
    p.content AS post_content,
    p.post_date,
    u.name AS user_name,
    c.name AS category_name
FROM
    post p,
    "USER" u,
    category c
WHERE
    p.id_user = u.id_user
    AND p.id_category = c.id_category;

--Vrem sa  analizam un comentariu si sa vedem la ce postare e si cine l a pus
SELECT
    c.id_comment,
    c.content AS comment_content,
    c.comment_date,
    u.name AS user_name,
    p.title AS post_title,
    cat.name AS category_name
FROM
    "COMMENT" c,
    "USER" u,
    post p,
    category cat
WHERE
    c.id_user = u.id_user
    AND c.id_post = p.id_post
    AND p.id_category = cat.id_category;

--vreau sa vad cine i a dat dislike lui john doe dupa 3 martie 2022
SELECT
    fu.name AS feedback_user_name,
    COUNT(*) AS negative_feedback_count
FROM
    post p,
    "USER" u,
    feedback f,
    "USER" fu
WHERE
    p.id_user = u.id_user
    AND u.name = 'John Doe'
    AND f.id_post = p.id_post
    AND f.type = 'negative'
    AND f.feedback_date > TO_DATE('2022-03-03', 'YYYY-MM-DD')
    AND f.id_user = fu.id_user
GROUP BY
    u.name,
    fu.name;

--vreau sa vad ce taguri foloseste eva miller si la ce categorii, ca sa vad daca face spam sau nu
SELECT
    t.name AS tag_name,
    c.name AS category_name
FROM
    "USER" u, post p, post_tags pt, tags t, category c
WHERE
    u.id_user = p.id_user
    AND p.id_post = pt.id_post
    AND pt.id_tag = t.id_tag
    AND p.id_category = c.id_category
    AND u.name = 'Eva Miller';

--vreau sa vad cel mai vechi utilizator 
SELECT
    name AS oldest_user
FROM
    "USER"
WHERE
    REGISTER_DATE = (SELECT MIN(REGISTER_DATE) FROM "USER");

--un utilizator s-a razgandit
SELECT type FROM feedback WHERE id_user = 3 AND id_post = 3;
UPDATE feedback
SET type = 'positive'
WHERE id_user = 3 AND id_post = 3;
SELECT type FROM feedback WHERE id_user = 3 AND id_post = 3;




--john doe si a actualizat datele contului

SELECT * FROM profile
WHERE id_user = 1;

UPDATE profile
SET
    phone_number = '0712345678',
    hobbies = 'Ciclism',
    description = 'Noua descriere a utilizatorului John Doe.',
    facebook = 'https://www.facebook.com/johndoe.nou',
    location = 'OrasNou'
WHERE id_user = 1;

SELECT * FROM profile
WHERE id_user = 1;

-- stergem toate postarile cu mai mult de 3 feedbackuri negative, si , implicit , toate datele aferente acestora din toate tabelele
DELETE FROM "COMMENT"
WHERE id_post IN (
    SELECT p.id_post
    FROM post p
    WHERE (
        SELECT COUNT(*) 
        FROM feedback f 
        WHERE f.id_post = p.id_post AND f.type = 'negative'
    ) > 3
);


DELETE FROM post_tags
WHERE id_post IN (
    SELECT p.id_post
    FROM post p
    WHERE (
        SELECT COUNT(*) 
        FROM feedback f 
        WHERE f.id_post = p.id_post AND f.type = 'negative'
    ) > 3
);

DELETE FROM feedback
WHERE id_post IN (
    SELECT p.id_post
    FROM post p
    WHERE (
        SELECT COUNT(*) 
        FROM feedback f 
        WHERE f.id_post = p.id_post AND f.type = 'negative'
    ) > 3
);

DELETE FROM post
WHERE id_post IN (
    SELECT p.id_post
    FROM post p
    WHERE (
        SELECT COUNT(*) 
        FROM feedback f 
        WHERE f.id_post = p.id_post AND f.type = 'negative'
    ) > 3
);




--testare constrangeri
-- "name_check" 
INSERT INTO category (id_category, name) VALUES (1, 'AB');

--"content_validation"
INSERT INTO "COMMENT" (id_comment, content, comment_date, id_post, id_user)
VALUES (1, '1234', SYSDATE, 1, 1);

 --"type_validation" 

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES (1, 1, 'invalid_type', SYSDATE);

-- "title_check" 

INSERT INTO post (id_post, title, content, post_date, id_user, id_category)
VALUES (1, 'AB', 'Valid content', SYSDATE, 1, 1);

--  "content_check" 

INSERT INTO post (id_post, title, content, post_date, id_user, id_category)
VALUES (2, 'Valid title', '123456789', SYSDATE, 1, 1);

-- "phone_validation" 

INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES (1, '1234567890', 'Hobbies', 'Description', 'https://www.facebook.com/user', 'Location');

-- "facebook_validation" 

INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES (2, '9876543210', 'Hobbies', 'Description', 'invalid_facebook_url', 'Location');

-- "tag_validation" 

INSERT INTO tags (id_tag, name) VALUES (1, 'tag_without_hash');

-- "name_validation" 

INSERT INTO "USER" (id_user, name, password, email, register_date, last_login)
VALUES (1, 'AB', 'ValidPass123', 'valid@example.com', SYSDATE, SYSDATE);

-- "password_validation" 

INSERT INTO "USER" (id_user, name, password, email, register_date, last_login)
VALUES (2, 'ValidUser', 'invalidPassword123', 'valid@example.com', SYSDATE, SYSDATE);

-- "email_validation" 

INSERT INTO "USER" (id_user, name, password, email, register_date, last_login)
VALUES (3, 'ValidUser', 'ValidPass123', 'invalid_email', SYSDATE, SYSDATE);

-- "trg_FEEDBACK_BRIU"

INSERT INTO feedback (id_post, id_user, type, feedback_date)
VALUES (1, 1, 'positive', SYSDATE + 1);

-- "trg_POST_BRIU"

INSERT INTO post (id_post, title, content, post_date, id_user, id_category)
VALUES (3, 'Valid title', 'Valid content', SYSDATE + 1, 1, 1);

-- "trg_USER_BRIU"
INSERT INTO "USER" (id_user, name, password, email, register_date, last_login)
VALUES (4, 'ValidUser', 'ValidPass123', 'valid@example.com', SYSDATE + 1, SYSDATE);

-- "trg1_USER_BRIU"

INSERT INTO "USER" (id_user, name, password, email, register_date, last_login)
VALUES (5, 'ValidUser', 'ValidPass123', 'valid@example.com', SYSDATE, SYSDATE + 1);


--  "email_uk" 
INSERT INTO "USER" (name, password, email, register_date, last_login)
VALUES ('Duplicate Email', 'Password123', 'john.doe@example.com', SYSDATE, SYSDATE);

--  "name_uk" 
INSERT INTO tags (name) VALUES ('#Programming');

-- "facebook_uk" 
INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES ((SELECT id_user FROM "USER" WHERE name = 'John Doe'), '1234567890', 'Reading, Cooking', 'A software engineer who loves to cook.', 'https://www.facebook.com/johndoe', 'City A');

-- "phone_number_uk" 
INSERT INTO profile (id_user, phone_number, hobbies, description, facebook, location)
VALUES ((SELECT id_user FROM "USER" WHERE name = 'Alice Smith'), '1234567890', 'Photography, Traveling', 'An adventurous photographer.', 'https://www.facebook.com/alicesmith', 'City B');

--  "name_uk" 
INSERT INTO category (name) VALUES ('Technology');

--  "name_uk" 
INSERT INTO tags (name) VALUES ('#Programming');
